﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grocery_store
{
    public partial class MenuForm : Form
    {
        public MenuForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("SYNTAX SYDICATE APPRECIATE YOU. COME AGAIN BYE!!");
            Application.Exit();
        }

        private void addProductButton_Click(object sender, EventArgs e)
        {
            AddProductForm addProductForm = new AddProductForm();
            addProductForm.ShowDialog();
        }

        private void shoppingMenuButton_Click(object sender, EventArgs e)
        {
            ShoppingPageForm shoppingPageForm = new ShoppingPageForm();
            shoppingPageForm.ShowDialog();
        }
    }
}
