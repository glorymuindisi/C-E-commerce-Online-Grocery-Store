﻿namespace grocery_store
{
    partial class ShoppingPageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.shoppingPageTitle = new System.Windows.Forms.Label();
            this.avaliableProductLabel = new System.Windows.Forms.Label();
            this.avaliableListBox = new System.Windows.Forms.ListBox();
            this.shoppingSelectButton = new System.Windows.Forms.Button();
            this.shoppingBasketListBox = new System.Windows.Forms.ListBox();
            this.shoppingBasketLabel = new System.Windows.Forms.Label();
            this.productSumLabel = new System.Windows.Forms.Label();
            this.totalSum = new System.Windows.Forms.Label();
            this.shoppingCheckoutButton = new System.Windows.Forms.Button();
            this.selectedProductIDLabel = new System.Windows.Forms.Label();
            this.selectedProductNamelabel = new System.Windows.Forms.Label();
            this.selectedProductPrice = new System.Windows.Forms.Label();
            this.selectedProductQuatityLabel = new System.Windows.Forms.Label();
            this.selectedProductName = new System.Windows.Forms.Label();
            this.selectedProductID = new System.Windows.Forms.Label();
            this.selectedProducttPrice = new System.Windows.Forms.Label();
            this.selectedPrductQuatity = new System.Windows.Forms.NumericUpDown();
            this.selectedProductUnit = new System.Windows.Forms.Label();
            this.addToBasketButton = new System.Windows.Forms.Button();
            this.ShoppingPageExitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.selectedPrductQuatity)).BeginInit();
            this.SuspendLayout();
            // 
            // shoppingPageTitle
            // 
            this.shoppingPageTitle.AutoSize = true;
            this.shoppingPageTitle.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shoppingPageTitle.Location = new System.Drawing.Point(212, 20);
            this.shoppingPageTitle.Name = "shoppingPageTitle";
            this.shoppingPageTitle.Size = new System.Drawing.Size(415, 55);
            this.shoppingPageTitle.TabIndex = 0;
            this.shoppingPageTitle.Text = "SHOPPING PAGE";
            this.shoppingPageTitle.Click += new System.EventHandler(this.shoppingPageTitle_Click);
            // 
            // avaliableProductLabel
            // 
            this.avaliableProductLabel.AutoSize = true;
            this.avaliableProductLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.avaliableProductLabel.Location = new System.Drawing.Point(45, 105);
            this.avaliableProductLabel.Name = "avaliableProductLabel";
            this.avaliableProductLabel.Size = new System.Drawing.Size(197, 20);
            this.avaliableProductLabel.TabIndex = 1;
            this.avaliableProductLabel.Text = "AVAILABLE PRODUCT";
            // 
            // avaliableListBox
            // 
            this.avaliableListBox.FormattingEnabled = true;
            this.avaliableListBox.ItemHeight = 20;
            this.avaliableListBox.Location = new System.Drawing.Point(49, 152);
            this.avaliableListBox.Name = "avaliableListBox";
            this.avaliableListBox.Size = new System.Drawing.Size(266, 224);
            this.avaliableListBox.TabIndex = 2;
            this.avaliableListBox.SelectedIndexChanged += new System.EventHandler(this.avaliableListBox_SelectedIndexChanged);
            // 
            // shoppingSelectButton
            // 
            this.shoppingSelectButton.BackColor = System.Drawing.Color.White;
            this.shoppingSelectButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.shoppingSelectButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shoppingSelectButton.ForeColor = System.Drawing.Color.SaddleBrown;
            this.shoppingSelectButton.Location = new System.Drawing.Point(49, 407);
            this.shoppingSelectButton.Name = "shoppingSelectButton";
            this.shoppingSelectButton.Size = new System.Drawing.Size(266, 48);
            this.shoppingSelectButton.TabIndex = 3;
            this.shoppingSelectButton.Text = "SELECT";
            this.shoppingSelectButton.UseVisualStyleBackColor = false;
            this.shoppingSelectButton.Click += new System.EventHandler(this.shoppingSelectButton_Click);
            // 
            // shoppingBasketListBox
            // 
            this.shoppingBasketListBox.FormattingEnabled = true;
            this.shoppingBasketListBox.ItemHeight = 20;
            this.shoppingBasketListBox.Location = new System.Drawing.Point(489, 152);
            this.shoppingBasketListBox.Name = "shoppingBasketListBox";
            this.shoppingBasketListBox.Size = new System.Drawing.Size(266, 224);
            this.shoppingBasketListBox.TabIndex = 4;
            this.shoppingBasketListBox.SelectedIndexChanged += new System.EventHandler(this.shoppingBasketListBox_SelectedIndexChanged);
            // 
            // shoppingBasketLabel
            // 
            this.shoppingBasketLabel.AutoSize = true;
            this.shoppingBasketLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shoppingBasketLabel.Location = new System.Drawing.Point(485, 105);
            this.shoppingBasketLabel.Name = "shoppingBasketLabel";
            this.shoppingBasketLabel.Size = new System.Drawing.Size(175, 20);
            this.shoppingBasketLabel.TabIndex = 5;
            this.shoppingBasketLabel.Text = "SHOPPING BASKET";
            this.shoppingBasketLabel.Click += new System.EventHandler(this.shoppingBasketLabel_Click);
            // 
            // productSumLabel
            // 
            this.productSumLabel.AutoSize = true;
            this.productSumLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productSumLabel.Location = new System.Drawing.Point(485, 396);
            this.productSumLabel.Name = "productSumLabel";
            this.productSumLabel.Size = new System.Drawing.Size(50, 20);
            this.productSumLabel.TabIndex = 6;
            this.productSumLabel.Text = "Sum:";
            // 
            // totalSum
            // 
            this.totalSum.AutoSize = true;
            this.totalSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalSum.Location = new System.Drawing.Point(537, 396);
            this.totalSum.Name = "totalSum";
            this.totalSum.Size = new System.Drawing.Size(19, 20);
            this.totalSum.TabIndex = 7;
            this.totalSum.Text = "0";
            // 
            // shoppingCheckoutButton
            // 
            this.shoppingCheckoutButton.BackColor = System.Drawing.Color.White;
            this.shoppingCheckoutButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.shoppingCheckoutButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shoppingCheckoutButton.ForeColor = System.Drawing.Color.SaddleBrown;
            this.shoppingCheckoutButton.Location = new System.Drawing.Point(489, 444);
            this.shoppingCheckoutButton.Name = "shoppingCheckoutButton";
            this.shoppingCheckoutButton.Size = new System.Drawing.Size(266, 48);
            this.shoppingCheckoutButton.TabIndex = 8;
            this.shoppingCheckoutButton.Text = "CHECKOUT";
            this.shoppingCheckoutButton.UseVisualStyleBackColor = false;
            this.shoppingCheckoutButton.Click += new System.EventHandler(this.shoppingCheckoutButton_Click);
            // 
            // selectedProductIDLabel
            // 
            this.selectedProductIDLabel.AutoSize = true;
            this.selectedProductIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectedProductIDLabel.Location = new System.Drawing.Point(45, 513);
            this.selectedProductIDLabel.Name = "selectedProductIDLabel";
            this.selectedProductIDLabel.Size = new System.Drawing.Size(100, 20);
            this.selectedProductIDLabel.TabIndex = 10;
            this.selectedProductIDLabel.Text = "Product ID:";
            // 
            // selectedProductNamelabel
            // 
            this.selectedProductNamelabel.AutoSize = true;
            this.selectedProductNamelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectedProductNamelabel.Location = new System.Drawing.Point(45, 472);
            this.selectedProductNamelabel.Name = "selectedProductNamelabel";
            this.selectedProductNamelabel.Size = new System.Drawing.Size(127, 20);
            this.selectedProductNamelabel.TabIndex = 11;
            this.selectedProductNamelabel.Text = "Product Name:";
            // 
            // selectedProductPrice
            // 
            this.selectedProductPrice.AutoSize = true;
            this.selectedProductPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectedProductPrice.Location = new System.Drawing.Point(45, 554);
            this.selectedProductPrice.Name = "selectedProductPrice";
            this.selectedProductPrice.Size = new System.Drawing.Size(121, 20);
            this.selectedProductPrice.TabIndex = 12;
            this.selectedProductPrice.Text = "Product Price:";
            this.selectedProductPrice.Click += new System.EventHandler(this.selectedProductPrice_Click);
            // 
            // selectedProductQuatityLabel
            // 
            this.selectedProductQuatityLabel.AutoSize = true;
            this.selectedProductQuatityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectedProductQuatityLabel.Location = new System.Drawing.Point(45, 593);
            this.selectedProductQuatityLabel.Name = "selectedProductQuatityLabel";
            this.selectedProductQuatityLabel.Size = new System.Drawing.Size(138, 20);
            this.selectedProductQuatityLabel.TabIndex = 13;
            this.selectedProductQuatityLabel.Text = "Product Quatity:";
            this.selectedProductQuatityLabel.Click += new System.EventHandler(this.selectedProductQualityLabel_Click);
            // 
            // selectedProductName
            // 
            this.selectedProductName.AutoSize = true;
            this.selectedProductName.Location = new System.Drawing.Point(209, 472);
            this.selectedProductName.Name = "selectedProductName";
            this.selectedProductName.Size = new System.Drawing.Size(33, 20);
            this.selectedProductName.TabIndex = 14;
            this.selectedProductName.Text = "null";
            // 
            // selectedProductID
            // 
            this.selectedProductID.AutoSize = true;
            this.selectedProductID.Location = new System.Drawing.Point(209, 513);
            this.selectedProductID.Name = "selectedProductID";
            this.selectedProductID.Size = new System.Drawing.Size(33, 20);
            this.selectedProductID.TabIndex = 15;
            this.selectedProductID.Text = "null";
            // 
            // selectedProducttPrice
            // 
            this.selectedProducttPrice.AutoSize = true;
            this.selectedProducttPrice.Location = new System.Drawing.Point(209, 554);
            this.selectedProducttPrice.Name = "selectedProducttPrice";
            this.selectedProducttPrice.Size = new System.Drawing.Size(33, 20);
            this.selectedProducttPrice.TabIndex = 16;
            this.selectedProducttPrice.Text = "null";
            // 
            // selectedPrductQuatity
            // 
            this.selectedPrductQuatity.Location = new System.Drawing.Point(195, 587);
            this.selectedPrductQuatity.Name = "selectedPrductQuatity";
            this.selectedPrductQuatity.Size = new System.Drawing.Size(120, 26);
            this.selectedPrductQuatity.TabIndex = 17;
            // 
            // selectedProductUnit
            // 
            this.selectedProductUnit.AutoSize = true;
            this.selectedProductUnit.Location = new System.Drawing.Point(332, 593);
            this.selectedProductUnit.Name = "selectedProductUnit";
            this.selectedProductUnit.Size = new System.Drawing.Size(35, 20);
            this.selectedProductUnit.TabIndex = 18;
            this.selectedProductUnit.Text = "unit";
            // 
            // addToBasketButton
            // 
            this.addToBasketButton.BackColor = System.Drawing.Color.White;
            this.addToBasketButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addToBasketButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addToBasketButton.ForeColor = System.Drawing.Color.SaddleBrown;
            this.addToBasketButton.Location = new System.Drawing.Point(49, 652);
            this.addToBasketButton.Name = "addToBasketButton";
            this.addToBasketButton.Size = new System.Drawing.Size(266, 48);
            this.addToBasketButton.TabIndex = 19;
            this.addToBasketButton.Text = "ADD TO BASKET";
            this.addToBasketButton.UseVisualStyleBackColor = false;
            this.addToBasketButton.Click += new System.EventHandler(this.addToBasketButton_Click);
            // 
            // ShoppingPageExitButton
            // 
            this.ShoppingPageExitButton.BackColor = System.Drawing.Color.White;
            this.ShoppingPageExitButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ShoppingPageExitButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShoppingPageExitButton.ForeColor = System.Drawing.Color.SaddleBrown;
            this.ShoppingPageExitButton.Location = new System.Drawing.Point(489, 652);
            this.ShoppingPageExitButton.Name = "ShoppingPageExitButton";
            this.ShoppingPageExitButton.Size = new System.Drawing.Size(266, 48);
            this.ShoppingPageExitButton.TabIndex = 20;
            this.ShoppingPageExitButton.Text = "EXIT";
            this.ShoppingPageExitButton.UseVisualStyleBackColor = false;
            this.ShoppingPageExitButton.Click += new System.EventHandler(this.ShoppingPageExitButton_Click);
            // 
            // ShoppingPageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OldLace;
            this.ClientSize = new System.Drawing.Size(846, 768);
            this.Controls.Add(this.ShoppingPageExitButton);
            this.Controls.Add(this.addToBasketButton);
            this.Controls.Add(this.selectedProductUnit);
            this.Controls.Add(this.selectedPrductQuatity);
            this.Controls.Add(this.selectedProducttPrice);
            this.Controls.Add(this.selectedProductID);
            this.Controls.Add(this.selectedProductName);
            this.Controls.Add(this.selectedProductQuatityLabel);
            this.Controls.Add(this.selectedProductPrice);
            this.Controls.Add(this.selectedProductNamelabel);
            this.Controls.Add(this.selectedProductIDLabel);
            this.Controls.Add(this.shoppingCheckoutButton);
            this.Controls.Add(this.totalSum);
            this.Controls.Add(this.productSumLabel);
            this.Controls.Add(this.shoppingBasketLabel);
            this.Controls.Add(this.shoppingBasketListBox);
            this.Controls.Add(this.shoppingSelectButton);
            this.Controls.Add(this.avaliableListBox);
            this.Controls.Add(this.avaliableProductLabel);
            this.Controls.Add(this.shoppingPageTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "ShoppingPageForm";
            this.Text = "ShoopingPageForm";
            this.Load += new System.EventHandler(this.ShoppingPageForm_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.selectedPrductQuatity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label shoppingPageTitle;
        private System.Windows.Forms.Label avaliableProductLabel;
        private System.Windows.Forms.ListBox avaliableListBox;
        private System.Windows.Forms.Button shoppingSelectButton;
        private System.Windows.Forms.ListBox shoppingBasketListBox;
        private System.Windows.Forms.Label shoppingBasketLabel;
        private System.Windows.Forms.Label productSumLabel;
        private System.Windows.Forms.Label totalSum;
        private System.Windows.Forms.Button shoppingCheckoutButton;
        private System.Windows.Forms.Label selectedProductIDLabel;
        private System.Windows.Forms.Label selectedProductNamelabel;
        private System.Windows.Forms.Label selectedProductPrice;
        private System.Windows.Forms.Label selectedProductQuatityLabel;
        private System.Windows.Forms.Label selectedProductName;
        private System.Windows.Forms.Label selectedProductID;
        private System.Windows.Forms.Label selectedProducttPrice;
        private System.Windows.Forms.NumericUpDown selectedPrductQuatity;
        private System.Windows.Forms.Label selectedProductUnit;
        private System.Windows.Forms.Button addToBasketButton;
        private System.Windows.Forms.Button ShoppingPageExitButton;
    }
}