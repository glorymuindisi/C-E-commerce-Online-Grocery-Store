﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace grocery_store
{
    internal class CapitalizedText
    {
        public string capitalized(string text)
        {
            char text1 = text[0];
            string fullText = text1.ToString().ToUpper() + text.Substring(1).ToLower();
            return fullText;
        }
    }
}
