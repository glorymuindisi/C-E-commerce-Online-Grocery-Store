﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace grocery_store
{
    internal class Products
    {
        
        public string Name;
        public string ID;
        public string Price;
        public string Unit;

        public string FullProduct()
        {
            CapitalizedText capitalizedText = new CapitalizedText();
            string capitalizedName = capitalizedText.capitalized(Name);
            string fullProduct = ($"{ID}{capitalizedName}@{Price}@{Unit}");
            return fullProduct;
        }
    }
}
