﻿//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.IO;
//namespace grocery_store
//{
//    internal class FileStreamReader
//    {
//        FileStream fileStream = new FileStream("SyndicateGroceriesStore.txt", FileMode.Open, FileAccess.Read);
//        StreamReader fileReader = new StreamReader(fileStream);
//        string productDetails = fileReader.ReadLine();
//    }
//}
