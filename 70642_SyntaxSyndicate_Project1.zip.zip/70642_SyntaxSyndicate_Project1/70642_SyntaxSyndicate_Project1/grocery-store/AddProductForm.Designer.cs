﻿namespace grocery_store
{
    partial class AddProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addProductLabel = new System.Windows.Forms.Label();
            this.productNameLabel = new System.Windows.Forms.Label();
            this.productIDLabel = new System.Windows.Forms.Label();
            this.productPriceLabel = new System.Windows.Forms.Label();
            this.productUnitLabel = new System.Windows.Forms.Label();
            this.productNametextBox = new System.Windows.Forms.TextBox();
            this.productIdTextbox = new System.Windows.Forms.TextBox();
            this.productPriceTextBox = new System.Windows.Forms.TextBox();
            this.productUnitBox = new System.Windows.Forms.ComboBox();
            this.autoIdCheckBox = new System.Windows.Forms.CheckBox();
            this.addProductExitbutton = new System.Windows.Forms.Button();
            this.addProductButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // addProductLabel
            // 
            this.addProductLabel.AutoSize = true;
            this.addProductLabel.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addProductLabel.Location = new System.Drawing.Point(127, 48);
            this.addProductLabel.Name = "addProductLabel";
            this.addProductLabel.Size = new System.Drawing.Size(420, 55);
            this.addProductLabel.TabIndex = 0;
            this.addProductLabel.Text = "ADD A PRODUCT";
            // 
            // productNameLabel
            // 
            this.productNameLabel.AutoSize = true;
            this.productNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productNameLabel.Location = new System.Drawing.Point(37, 164);
            this.productNameLabel.Name = "productNameLabel";
            this.productNameLabel.Size = new System.Drawing.Size(193, 29);
            this.productNameLabel.TabIndex = 1;
            this.productNameLabel.Text = "Product Name :";
            this.productNameLabel.Click += new System.EventHandler(this.productNameLabel_Click);
            // 
            // productIDLabel
            // 
            this.productIDLabel.AutoSize = true;
            this.productIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productIDLabel.Location = new System.Drawing.Point(37, 239);
            this.productIDLabel.Name = "productIDLabel";
            this.productIDLabel.Size = new System.Drawing.Size(156, 29);
            this.productIDLabel.TabIndex = 2;
            this.productIDLabel.Text = "Product ID : ";
            // 
            // productPriceLabel
            // 
            this.productPriceLabel.AutoSize = true;
            this.productPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productPriceLabel.Location = new System.Drawing.Point(37, 312);
            this.productPriceLabel.Name = "productPriceLabel";
            this.productPriceLabel.Size = new System.Drawing.Size(185, 29);
            this.productPriceLabel.TabIndex = 3;
            this.productPriceLabel.Text = "Product Price :";
            this.productPriceLabel.Click += new System.EventHandler(this.productPriceLabel_Click);
            // 
            // productUnitLabel
            // 
            this.productUnitLabel.AutoSize = true;
            this.productUnitLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productUnitLabel.Location = new System.Drawing.Point(37, 384);
            this.productUnitLabel.Name = "productUnitLabel";
            this.productUnitLabel.Size = new System.Drawing.Size(170, 29);
            this.productUnitLabel.TabIndex = 4;
            this.productUnitLabel.Text = "Product Unit :";
            this.productUnitLabel.Click += new System.EventHandler(this.productUnitLabel_Click);
            // 
            // productNametextBox
            // 
            this.productNametextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.productNametextBox.Location = new System.Drawing.Point(259, 164);
            this.productNametextBox.Name = "productNametextBox";
            this.productNametextBox.Size = new System.Drawing.Size(252, 26);
            this.productNametextBox.TabIndex = 5;
            this.productNametextBox.TextChanged += new System.EventHandler(this.productNametextBox_TextChanged);
            // 
            // productIdTextbox
            // 
            this.productIdTextbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.productIdTextbox.Location = new System.Drawing.Point(259, 242);
            this.productIdTextbox.Name = "productIdTextbox";
            this.productIdTextbox.Size = new System.Drawing.Size(252, 26);
            this.productIdTextbox.TabIndex = 6;
            this.productIdTextbox.TextChanged += new System.EventHandler(this.productIdTextbox_TextChanged);
            // 
            // productPriceTextBox
            // 
            this.productPriceTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.productPriceTextBox.Location = new System.Drawing.Point(259, 317);
            this.productPriceTextBox.Name = "productPriceTextBox";
            this.productPriceTextBox.Size = new System.Drawing.Size(252, 26);
            this.productPriceTextBox.TabIndex = 7;
            // 
            // productUnitBox
            // 
            this.productUnitBox.BackColor = System.Drawing.Color.White;
            this.productUnitBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.productUnitBox.ForeColor = System.Drawing.SystemColors.MenuText;
            this.productUnitBox.FormattingEnabled = true;
            this.productUnitBox.Items.AddRange(new object[] {
            "Kg",
            "Liter",
            "Piece"});
            this.productUnitBox.Location = new System.Drawing.Point(259, 388);
            this.productUnitBox.Name = "productUnitBox";
            this.productUnitBox.Size = new System.Drawing.Size(252, 28);
            this.productUnitBox.TabIndex = 8;
            // 
            // autoIdCheckBox
            // 
            this.autoIdCheckBox.AutoSize = true;
            this.autoIdCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.autoIdCheckBox.Location = new System.Drawing.Point(551, 241);
            this.autoIdCheckBox.Name = "autoIdCheckBox";
            this.autoIdCheckBox.Size = new System.Drawing.Size(110, 29);
            this.autoIdCheckBox.TabIndex = 9;
            this.autoIdCheckBox.Text = "Auto ID";
            this.autoIdCheckBox.UseVisualStyleBackColor = true;
            this.autoIdCheckBox.CheckedChanged += new System.EventHandler(this.autoIdCheckBox_CheckedChanged);
            // 
            // addProductExitbutton
            // 
            this.addProductExitbutton.BackColor = System.Drawing.Color.White;
            this.addProductExitbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addProductExitbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addProductExitbutton.ForeColor = System.Drawing.Color.SaddleBrown;
            this.addProductExitbutton.Location = new System.Drawing.Point(220, 558);
            this.addProductExitbutton.Name = "addProductExitbutton";
            this.addProductExitbutton.Size = new System.Drawing.Size(280, 57);
            this.addProductExitbutton.TabIndex = 21;
            this.addProductExitbutton.Text = "EXIT";
            this.addProductExitbutton.UseVisualStyleBackColor = false;
            this.addProductExitbutton.Click += new System.EventHandler(this.addProductExitbutton_Click);
            // 
            // addProductButton
            // 
            this.addProductButton.BackColor = System.Drawing.Color.White;
            this.addProductButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addProductButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addProductButton.ForeColor = System.Drawing.Color.SaddleBrown;
            this.addProductButton.Location = new System.Drawing.Point(220, 474);
            this.addProductButton.Name = "addProductButton";
            this.addProductButton.Size = new System.Drawing.Size(280, 57);
            this.addProductButton.TabIndex = 22;
            this.addProductButton.Text = "ADD PRODUCT";
            this.addProductButton.UseVisualStyleBackColor = false;
            this.addProductButton.Click += new System.EventHandler(this.addProductButton_Click);
            // 
            // AddProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OldLace;
            this.ClientSize = new System.Drawing.Size(705, 632);
            this.Controls.Add(this.addProductButton);
            this.Controls.Add(this.addProductExitbutton);
            this.Controls.Add(this.autoIdCheckBox);
            this.Controls.Add(this.productUnitBox);
            this.Controls.Add(this.productPriceTextBox);
            this.Controls.Add(this.productIdTextbox);
            this.Controls.Add(this.productNametextBox);
            this.Controls.Add(this.productUnitLabel);
            this.Controls.Add(this.productPriceLabel);
            this.Controls.Add(this.productIDLabel);
            this.Controls.Add(this.productNameLabel);
            this.Controls.Add(this.addProductLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "AddProductForm";
            this.Text = "AddProductForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label addProductLabel;
        private System.Windows.Forms.Label productNameLabel;
        private System.Windows.Forms.Label productIDLabel;
        private System.Windows.Forms.Label productPriceLabel;
        private System.Windows.Forms.Label productUnitLabel;
        private System.Windows.Forms.TextBox productNametextBox;
        private System.Windows.Forms.TextBox productIdTextbox;
        private System.Windows.Forms.TextBox productPriceTextBox;
        private System.Windows.Forms.ComboBox productUnitBox;
        private System.Windows.Forms.CheckBox autoIdCheckBox;
        private System.Windows.Forms.Button addProductExitbutton;
        private System.Windows.Forms.Button addProductButton;
    }
}