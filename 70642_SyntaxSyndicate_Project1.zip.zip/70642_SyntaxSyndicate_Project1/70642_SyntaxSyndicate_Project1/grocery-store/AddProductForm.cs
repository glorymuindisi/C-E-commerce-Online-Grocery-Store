﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

//TO DOs
//1.Add id length limitation*******
//2.make the user select/type out only what is in the dropdown *****done
//3.add errors messages*****done

namespace grocery_store
{
    public partial class AddProductForm : Form
    {
        public AddProductForm()
        {
            InitializeComponent();
        }
     
        private void autoIdCheckBox_CheckedChanged(object sender, EventArgs e)
        {

            if (autoIdCheckBox.Checked)
            {
                if (productNametextBox.Text == "")
                {
                    MessageBox.Show("Please enter product name", "Error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                    autoIdCheckBox.Checked = false;
                }
                else
                {
                    CapitalizedText capitalizedText = new CapitalizedText();

                    Products products = new Products();
                    products.Name = capitalizedText.capitalized(productNametextBox.Text);
                    char letter1 = products.Name[0];
                    char letter2 = products.Name[products.Name.Length - 1];

                    Random random = new Random();
                    int randomId = random.Next(1000, 9999);
                    string randomID = $"{letter1}{randomId}{letter2}";
                    productIdTextbox.Text = randomID;
                }
            }
            else productIdTextbox.Text = string.Empty;
        }

        private void addProductButton_Click(object sender, EventArgs e)
        {

            //LINKING PROUDCT CLASS FIELD TO THE INPUTED FIELD VALUE
            Products products = new Products();
            products.Name = productNametextBox.Text;
            products.ID = productIdTextbox.Text;
            products.Price = productPriceTextBox.Text;
            products.Unit = Convert.ToString(productUnitBox.SelectedItem);

            // ERROR
            ProductFormValidation productFormValidation = new ProductFormValidation();
            string validation = productFormValidation.FieldsValidation(products);

            if (validation != null )
            {
                MessageBox.Show(validation," Error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error); 
            }
            else
            {
                //CREATE AND SAVE IN FILE
                FileStream productFile = new FileStream("SyndicateGroceriesStore.txt", FileMode.Append, FileAccess.Write);
                StreamWriter streamWriter = new StreamWriter(productFile);
                streamWriter.WriteLine(products.FullProduct());
                streamWriter.Close();
                productFile.Close();

                //MESSAGE
                MessageBox.Show("Product Added");
                productNametextBox.Clear();
                productIdTextbox.Clear();
                productPriceTextBox.Clear();
                autoIdCheckBox.Checked = false;
                productUnitBox.SelectedIndex = -1;
           
            }
        

        }
        private void addProductExitbutton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("THANKS FOR ADDING PRODUCT.");
            this.Close();
        }

        private void productNametextBox_TextChanged(object sender, EventArgs e) { }

        private void productNameLabel_Click(object sender, EventArgs e)
        {

        }

        private void productUnitLabel_Click(object sender, EventArgs e)
        {

        }

        private void productPriceLabel_Click(object sender, EventArgs e)
        {

        }

        private void productIdTextbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}