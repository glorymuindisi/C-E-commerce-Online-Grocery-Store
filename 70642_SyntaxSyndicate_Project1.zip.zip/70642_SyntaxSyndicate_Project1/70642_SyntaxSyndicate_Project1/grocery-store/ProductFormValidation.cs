﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace grocery_store
{
    internal class ProductFormValidation
    {
        public string FieldsValidation(Products product)
        {
              if (string.IsNullOrWhiteSpace(product.Name))
            {
                return "Please enter the product name";
            }

           else if (string.IsNullOrWhiteSpace(product.ID) || product.ID.Length != 6)
            {
                return "ID must be 6 characters";
            }

          
  else if (!decimal.TryParse(product.Price, out _)) 
                {
                return "Please enter a valid product price";
            }

          else  if (string.IsNullOrWhiteSpace(product.Unit))
            {
                return "Please select the unit";
            }

            

            return null;
        }

    }
}
