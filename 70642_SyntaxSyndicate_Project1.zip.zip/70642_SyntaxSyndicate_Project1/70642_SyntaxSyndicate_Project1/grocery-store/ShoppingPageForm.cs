﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace grocery_store
{
    public partial class ShoppingPageForm : Form
    {
        public ShoppingPageForm()
        {
            InitializeComponent();
        }
        private void ShoppingPageForm_Load_1(object sender, EventArgs e)
        {

            FileStream fileStream = new FileStream("SyndicateGroceriesStore.txt", FileMode.Open, FileAccess.Read);
            StreamReader fileReader = new StreamReader(fileStream);
            while (!fileReader.EndOfStream)
            {
                string productDetails = fileReader.ReadLine();
                int demarcation = productDetails.IndexOf("@");
                string productName = productDetails.Substring(6, demarcation - 6);
                avaliableListBox.Items.Add(productName);
            }
            fileReader.Close();
            fileStream.Close();
        }
  
        private void shoppingSelectButton_Click(object sender, EventArgs e)
        {
            FileStream fileStream = new FileStream("SyndicateGroceriesStore.txt", FileMode.Open, FileAccess.Read);
            StreamReader fileReader = new StreamReader(fileStream);
            if (avaliableListBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a product from the list.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
         
            while (!fileReader.EndOfStream)
            {
                string productDetails = fileReader.ReadLine();
                int demarcation = productDetails.IndexOf("@");
                int secondDemarcation = productDetails.IndexOf("@", demarcation + 1);
                string productName = productDetails.Substring(6, demarcation - 6);
                if (avaliableListBox.SelectedItem.ToString() == productName)
                {
                    selectedProductName.Text = productName;
                    selectedProductID.Text = productDetails.Substring(0, 6);
                    selectedProducttPrice.Text = productDetails.Substring(demarcation + 1, secondDemarcation - (demarcation + 1));
                }
            }
        }

        private void addToBasketButton_Click(object sender, EventArgs e)
        {
            if(Convert.ToInt32(selectedPrductQuatity.Value) == 0)
            {
                MessageBox.Show("Please enter Quatity", "Error", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
            else
            {
                shoppingBasketListBox.Items.Add($"{selectedPrductQuatity.Value}x{selectedProductName.Text}");
                double totalPrice = Convert.ToDouble(selectedPrductQuatity.Value) * Convert.ToDouble(selectedProducttPrice.Text);
                double currentTotal = Convert.ToDouble(totalSum.Text);
                currentTotal += totalPrice;
                totalSum.Text = currentTotal.ToString();
            }
        }
        private void shoppingCheckoutButton_Click(object sender, EventArgs e)
        {
            if (totalSum.Text == "0")
            {
       
             DialogResult result = MessageBox.Show("You don't want to shop with us?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(result == DialogResult.Yes)
                {
                    MessageBox.Show("Thank you, I hope you come again !!");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Please Select a Product");
                }
                return;
            }

            MessageBox.Show($"Your Sum is: {totalSum.Text}\n Thank you for shopping");
            shoppingBasketListBox.Items.Clear();
            totalSum.Text = "0";
        }
        private void ShoppingPageExitButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("THANK FOR SHOPPING!!");
            this.Close();
        }
        

        private void selectedProductQualityLabel_Click(object sender, EventArgs e) { }
        private void avaliableListBox_SelectedIndexChanged(object sender, EventArgs e) { }

        private void label2_Click(object sender, EventArgs e) { }

        private void shoppingPageTitle_Click(object sender, EventArgs e)
        {

        }

        private void shoppingBasketListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void shoppingBasketLabel_Click(object sender, EventArgs e)
        {

        }

        private void selectedProductPrice_Click(object sender, EventArgs e)
        {

        }
    }
}
