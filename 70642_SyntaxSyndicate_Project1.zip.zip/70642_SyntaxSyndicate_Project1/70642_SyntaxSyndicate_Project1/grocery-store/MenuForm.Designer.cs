﻿namespace grocery_store
{
    partial class MenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupName = new System.Windows.Forms.Label();
            this.addProductButton = new System.Windows.Forms.Button();
            this.shoppingMenuButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // groupName
            // 
            this.groupName.AutoSize = true;
            this.groupName.Location = new System.Drawing.Point(472, 624);
            this.groupName.Name = "groupName";
            this.groupName.Size = new System.Drawing.Size(100, 20);
            this.groupName.TabIndex = 1;
            this.groupName.Text = "Syndicate_...";
            // 
            // addProductButton
            // 
            this.addProductButton.BackColor = System.Drawing.Color.White;
            this.addProductButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addProductButton.ForeColor = System.Drawing.Color.SaddleBrown;
            this.addProductButton.Location = new System.Drawing.Point(103, 195);
            this.addProductButton.Name = "addProductButton";
            this.addProductButton.Size = new System.Drawing.Size(325, 56);
            this.addProductButton.TabIndex = 2;
            this.addProductButton.Text = "ADD PRODUCTS";
            this.addProductButton.UseVisualStyleBackColor = false;
            this.addProductButton.Click += new System.EventHandler(this.addProductButton_Click);
            // 
            // shoppingMenuButton
            // 
            this.shoppingMenuButton.BackColor = System.Drawing.Color.White;
            this.shoppingMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shoppingMenuButton.ForeColor = System.Drawing.Color.SaddleBrown;
            this.shoppingMenuButton.Location = new System.Drawing.Point(103, 270);
            this.shoppingMenuButton.Name = "shoppingMenuButton";
            this.shoppingMenuButton.Size = new System.Drawing.Size(325, 56);
            this.shoppingMenuButton.TabIndex = 3;
            this.shoppingMenuButton.Text = "SHOPPING MENU";
            this.shoppingMenuButton.UseVisualStyleBackColor = false;
            this.shoppingMenuButton.Click += new System.EventHandler(this.shoppingMenuButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.White;
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.ForeColor = System.Drawing.Color.SaddleBrown;
            this.exitButton.Location = new System.Drawing.Point(103, 402);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(325, 56);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "EXIT";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(98, 495);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(330, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Programmed by syntax syndicate";
            // 
            // MenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::grocery_store.Properties.Resources.OOPproject;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(534, 529);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.shoppingMenuButton);
            this.Controls.Add(this.addProductButton);
            this.Controls.Add(this.groupName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MenuForm";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label groupName;
        private System.Windows.Forms.Button addProductButton;
        private System.Windows.Forms.Button shoppingMenuButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label1;
    }
}

